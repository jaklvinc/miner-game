# Semestrální práce

V tomto adresáři doporučujeme vyvíjet vaší semestrální práci. Struktura semestrální práce a tedy i tohoto adresář by měla odpovídat informacím na [Courses PA2 - Semestrální práce](https://courses.fit.cvut.cz/BI-PA2/semestral.html).

Přímo v tomto adresáři doporučujeme vyvořit podadresář `<login>`, kde `<login>` je tvůj username a v tomto podadresáři dále vyvíjet. Dále si zde můžeš například vytvořit skript `pack.sh`, který zabalí tvoji semestrální práci do `.zip` souboru, přesně podle pokynů na Courses.
